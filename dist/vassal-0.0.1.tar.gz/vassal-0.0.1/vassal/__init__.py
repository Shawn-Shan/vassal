from vassal.ssh import SSH
from vassal.terminal import Terminal
from vassal.scheduler import Scheduler

name = "vassal"
